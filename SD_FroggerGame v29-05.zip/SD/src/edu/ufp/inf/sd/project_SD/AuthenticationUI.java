package edu.ufp.inf.sd.project_SD;

import edu.ufp.inf.sd.project_SD.client.GameClient;
import edu.ufp.inf.sd.project_SD.server.AuthenticationRI;
import edu.ufp.inf.sd.project_SD.server.SessionRI;
import edu.ufp.inf.sd.project_SD.util.rmisetup.SetupContextRMI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AuthenticationUI {
    private JFrame frame;
    private JPanel contentPane;
    private SetupContextRMI contextRMI;
    private AuthenticationRI authenticationRI;
    private SessionRI sessionRI;

    public static void main(String[] args) {
        if (args != null && args.length < 2) {
            System.err.println("usage: java [options] edu.ufp.inf.sd.project_SD.server.GameServer <rmi_registry_ip> <rmi_registry_port> <service_name>");
            System.exit(-1);
        } else {
            //1. ============ Setup client RMI context ============
            GameClient gc = new GameClient(args);
            //2. ============ Lookup service ============
            gc.lookupService();
            //3. ============ Play with service ============
            gc.playService();
        }
    }

    public AuthenticationUI(String args[]) {
        try {
            //List ans set args
            SetupContextRMI.printArgs(this.getClass().getName(), args);
            String registryIP = args[0];
            String registryPort = args[1];
            String serviceName = args[2];
            //Create a context for RMI setup
            contextRMI = new SetupContextRMI(this.getClass(), registryIP, registryPort, new String[]{serviceName});
            lookupService();
        } catch (RemoteException e) {
            Logger.getLogger(GameClient.class.getName()).log(Level.SEVERE, null, e);
        }
    }


    public Remote lookupService() {
        try {
            //Get proxy MAIL_TO_ADDR rmiregistry
            Registry registry = contextRMI.getRegistry();
            //Lookup service on rmiregistry and wait for calls
            if (registry != null) {
                //Get service url (including servicename)
                String serviceUrl = contextRMI.getServicesUrl(0);
                Logger.getLogger(this.getClass().getName()).log(Level.INFO, "going MAIL_TO_ADDR lookup service @ {0}", serviceUrl);

                //============ Get proxy MAIL_TO_ADDR HelloWorld service ============
                authenticationRI = (AuthenticationRI) registry.lookup(serviceUrl);
            } else {
                Logger.getLogger(this.getClass().getName()).log(Level.INFO, "registry not bound (check IPs). :(");
                //registry = LocateRegistry.createRegistry(1099);
            }
        } catch (RemoteException | NotBoundException ex) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return authenticationRI;
    }

    private void initUI() {
        frame = new Frame();
        contentPane = new JPanel();
        contentPane.setLayout(new CardLayout(20, 20));
        // Se authenticationRI == null, mostrar ReconnectPanel
        // Caso contrário, mostrar LoginPanel
        contentPane.add(new LoginPanel());
        contentPane.add(new RegisterPanel());
        contentPane.add(new SessionPanel());

        frame.add(contentPane);
        //frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
    }

    private class Frame extends JFrame {
        public Frame() {
            super();
            setSize(500, 400);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
    }

    private class LoginPanel extends JPanel {

        private JLabel userLabel;
        private JTextField userText;
        private JLabel passwordLabel;
        private JPasswordField passwordText;
        private JLabel message;
        private JButton loginButton;
        private JButton registerButton;

        public LoginPanel() {

            super();
            setLayout(null);

            int titleWidth = 270;
            int titleHeight = 55;
            int titleX = 100;
            int titleY = 20;
            int titleSize = 47;

            JLabel gameTitle = new JLabel("Frogger");
            gameTitle.setBounds(0, 0, titleWidth, titleHeight);
            gameTitle.setFont(new Font("Ravie", Font.BOLD, titleSize));
            gameTitle.setForeground(new Color(251, 102, 8));
            gameTitle.setLocation(titleX, titleY);
            add(gameTitle);

            JLabel gameTitleShadow = new JLabel("Frogger");
            gameTitleShadow.setBounds(0, 0, titleWidth, titleHeight);
            gameTitleShadow.setFont(new Font("Ravie", Font.BOLD, titleSize));
            gameTitleShadow.setForeground(new Color(68, 71, 140));
            gameTitleShadow.setBackground(Color.black);
            gameTitleShadow.setLocation(titleX + 2, titleY + 2);
            add(gameTitleShadow);

            userLabel = new JLabel("User");
            userLabel.setBounds(100, 100,80,25);
            add(userLabel);

            userText = new JTextField(20);
            userText.setBounds(200, 100, 165, 25);
            add(userText);

            passwordLabel = new JLabel("Password");
            passwordLabel.setBounds(100, 130,80,25);
            add(passwordLabel);

            passwordText = new JPasswordField(20);
            passwordText.setBounds(200, 130, 165, 25);
            add(passwordText);

            loginButton = new JButton("Login");
            loginButton.setBounds(200, 180, 100, 50);
            loginButton.addActionListener(new LoginButtonHandler());
            add(loginButton);

            registerButton = new JButton("Register");
            registerButton.setBounds(200, 240, 100, 50);
            registerButton.addActionListener(new RegisterButtonHandler());
            add(registerButton);

        }

        private class LoginButtonHandler implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    sessionRI = authenticationRI.login(userText.getText(), passwordText.getText());
                    if(sessionRI == null) {
                        message.setText("Username or password are not correct!");
                        return;
                    }

                    ((CardLayout) contentPane.getLayout()).next(contentPane);
                    ((CardLayout) contentPane.getLayout()).next(contentPane);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }

        private class RegisterButtonHandler implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                ((CardLayout) contentPane.getLayout()).next(contentPane);
            }
        }
    }

    private class RegisterPanel extends JPanel {

        private JLabel emailLabel;
        private JTextField nameText;
        private JLabel usernameLabel;
        private JTextField usernameText;
        private JLabel passwordLabel;
        private JPasswordField passwordText;
        private JLabel message;
        private JButton loginButton;
        private JButton registerButton;

        public RegisterPanel() {
            super();
            setLayout(null);

            emailLabel = new JLabel("Email");
            emailLabel.setBounds(100, 20,80,25);
            add(emailLabel);

            nameText = new JTextField(20);
            nameText.setBounds(200, 20, 165, 25);
            add(nameText);

            usernameLabel = new JLabel("Username");
            usernameLabel.setBounds(100, 50,80,25);
            add(usernameLabel);

            usernameText = new JTextField(20);
            usernameText.setBounds(200, 50, 165, 25);
            add(usernameText);

            passwordLabel = new JLabel("Password");
            passwordLabel.setBounds(100, 80,80,25);
            add(passwordLabel);

            passwordText = new JPasswordField(20);
            passwordText.setBounds(200, 80, 165, 25);
            add(passwordText);

            registerButton = new JButton("Register");
            registerButton.setBounds(200, 120, 100, 50);
            registerButton.addActionListener(new RegisterButtonHandler());
            add(registerButton);

            loginButton = new JButton("Login");
            loginButton.setBounds(200, 180, 100, 50);
            loginButton.addActionListener(new LoginButtonHandler());
            add(loginButton);
        }

        private class RegisterButtonHandler implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    if(!authenticationRI.register(nameText.getText(), passwordText.getText())) {
                        message.setText("Username already taken!");
                        return;
                    }

                    ((CardLayout) contentPane.getLayout()).previous(contentPane);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }

        private class LoginButtonHandler implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                ((CardLayout) contentPane.getLayout()).previous(contentPane);
            }
        }
    }

    private class SessionPanel extends JPanel {

        private JLabel emailLabel;
        private JTextField nameText;
        private JLabel usernameLabel;
        private JTextField usernameText;
        private JLabel passwordLabel;
        private JPasswordField passwordText;
        private JLabel message;
        private JButton loginButton;
        private JButton registerButton;

        public SessionPanel() {
            super();
            setLayout(null);

            emailLabel = new JLabel("Session UI");
            emailLabel.setBounds(100, 20,80,25);
            add(emailLabel);

            nameText = new JTextField(20);
            nameText.setBounds(200, 20, 165, 25);
            add(nameText);

            usernameLabel = new JLabel("Username");
            usernameLabel.setBounds(100, 50,80,25);
            add(usernameLabel);

            usernameText = new JTextField(20);
            usernameText.setBounds(200, 50, 165, 25);
            add(usernameText);

            passwordLabel = new JLabel("Password");
            passwordLabel.setBounds(100, 80,80,25);
            add(passwordLabel);

            passwordText = new JPasswordField(20);
            passwordText.setBounds(200, 80, 165, 25);
            add(passwordText);

            registerButton = new JButton("Register");
            registerButton.setBounds(200, 120, 100, 50);
            registerButton.addActionListener(new RegisterButtonHandler());
            add(registerButton);

            loginButton = new JButton("Login");
            loginButton.setBounds(200, 180, 100, 50);
            loginButton.addActionListener(new LoginButtonHandler());
            add(loginButton);
        }

        private class RegisterButtonHandler implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    if(!authenticationRI.register(nameText.getText(), passwordText.getText())) {
                        message.setText("Username already taken!");
                        return;
                    }

                    ((CardLayout) contentPane.getLayout()).previous(contentPane);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }

        private class LoginButtonHandler implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                ((CardLayout) contentPane.getLayout()).previous(contentPane);
            }
        }
    }
}