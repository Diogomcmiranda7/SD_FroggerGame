package edu.ufp.inf.sd.project_SD;

public class Client {
    public static void main(String[] args) {
        new Client();
    }

    private enum ClientState {
        AUTHENTICATION, SESSION, GAME
    }

    private ClientState clientState;
    private AuthenticationUI authentication;

    public Client() {
        clientState = ClientState.AUTHENTICATION;
        //authentication = new AuthenticationUI();
    }
}
