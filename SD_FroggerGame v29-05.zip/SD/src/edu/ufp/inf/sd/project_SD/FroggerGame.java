package edu.ufp.inf.sd.project_SD;

import java.awt.event.KeyEvent;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import edu.ufp.inf.sd.project_SD.client.FroggerRI;
import edu.ufp.inf.sd.project_SD.effects.AudioEfx;
import edu.ufp.inf.sd.project_SD.effects.HeatWave;
import edu.ufp.inf.sd.project_SD.effects.WindGust;
import edu.ufp.inf.sd.project_SD.entities.Frogger;
import edu.ufp.inf.sd.project_SD.entities.Goal;
import edu.ufp.inf.sd.project_SD.entities.MovingEntity;
import edu.ufp.inf.sd.project_SD.entities.MovingEntityFactory;
import edu.ufp.inf.sd.project_SD.server.FroggerGameRI;
import edu.ufp.inf.sd.project_SD.server.SessionRI;
import jig.engine.ImageResource;
import jig.engine.PaintableCanvas;
import jig.engine.RenderingContext;
import jig.engine.ResourceFactory;
import jig.engine.PaintableCanvas.JIGSHAPE;
import jig.engine.hli.ImageBackgroundLayer;
import jig.engine.hli.StaticScreenGame;
import jig.engine.physics.AbstractBodyLayer;
import jig.engine.util.Vector2D;

public class FroggerGame extends StaticScreenGame {
	static final public int WORLD_WIDTH = (13*32);
	static final public int WORLD_HEIGHT = (14*32);
	static final public Vector2D FROGGER_START = new Vector2D(6*32,WORLD_HEIGHT-32);

	static final public String RSC_PATH = "edu/ufp/inf/sd/project_SD/resources/";
	static public final String SPRITE_SHEET = RSC_PATH + "frogger_sprites.png";


	static final int FROGGER_LIVES      = 5;
	static final int STARTING_LEVEL     = 1;
	static final public int DEFAULT_LEVEL_TIME = 60;

	private FroggerCollisionDetection frogCol;
	private final List<Frogger> frogs;
	private Frogger mainFrog;
	private AudioEfx audiofx;
	private final FroggerUI ui;
	private final WindGust wind;
	private final HeatWave hwave;
	private final GoalManager goalmanager;

	private final AbstractBodyLayer<MovingEntity> movingObjectsLayer;
	private final AbstractBodyLayer<MovingEntity> particleLayer;

	private MovingEntityFactory roadLine1;
	private MovingEntityFactory roadLine2;
	private MovingEntityFactory roadLine3;
	private MovingEntityFactory roadLine4;
	private MovingEntityFactory roadLine5;

	private MovingEntityFactory riverLine1;
	private MovingEntityFactory riverLine2;
	private MovingEntityFactory riverLine3;
	private MovingEntityFactory riverLine4;
	private MovingEntityFactory riverLine5;

	private final ImageBackgroundLayer backgroundLayer;

	protected enum GameState {
		INTRO, INSTRUCTIONS, PLAY, OVER, FINISH
	}
	protected GameState gameState = GameState.INTRO;
	protected int GameLevel = STARTING_LEVEL;

	public int GameLives    = FROGGER_LIVES;
	public int GameScore    = 0;

	public int levelTimer = DEFAULT_LEVEL_TIME;

	private boolean space_has_been_released = false;
	private boolean keyPressed = false;
	private boolean listenInput = true;

	private boolean networked = false;

	private SessionRI sessionRI;
	private FroggerGameRI froggerGame;
	private String mainFrogName;

	public FroggerGame(SessionRI sessionRI, FroggerGameRI froggerGame, String mainFrogName) throws RemoteException {
		super(WORLD_WIDTH, WORLD_HEIGHT, false);

		if ( sessionRI!=null && froggerGame!=null && mainFrogName!=null) {
			this.networked = true;
			this.sessionRI = sessionRI;
			this.froggerGame = sessionRI.getFroggerGame(froggerGame.getName());
			this.mainFrogName = mainFrogName;
		}

		gameframe.setTitle("Frogger");

		ResourceFactory.getFactory().loadResources(RSC_PATH, "resources.xml");

		ImageResource bkg = ResourceFactory.getFactory().getFrames(SPRITE_SHEET + "#background").get(0);
		backgroundLayer = new ImageBackgroundLayer(bkg, WORLD_WIDTH, WORLD_HEIGHT, ImageBackgroundLayer.TILE_IMAGE);

		// Used in CollisionObject, basically 2 different collision spheres
		// 30x30 is a large sphere (sphere that fits inside a 30x30 pixel rectangle)
		//  4x4 is a tiny sphere
		PaintableCanvas.loadDefaultFrames("col", 30, 30, 2, JIGSHAPE.RECTANGLE, null);
		PaintableCanvas.loadDefaultFrames("colSmall", 4, 4, 2, JIGSHAPE.RECTANGLE, null);

		frogs = new ArrayList<>();
		if (this.networked) {
			List<FroggerRI> remoteFroggers = this.froggerGame.getFroggers();
			for (FroggerRI oneFrogger: remoteFroggers) {
				Frogger createdFrogger = new Frogger(this);
				frogs.add(createdFrogger);
				if (oneFrogger.getName().equals(mainFrogName)) {
					this.mainFrog = createdFrogger;
					frogCol = new FroggerCollisionDetection(mainFrog);
					audiofx = new AudioEfx(frogCol, mainFrog);
				}
			}
		} else {
			frogs.add(new Frogger(this));
			for (Frogger frog : frogs) {
				frogCol = new FroggerCollisionDetection(frog);
				audiofx = new AudioEfx(frogCol, frog);
			}
			mainFrog = frogs.get(0);
		}
		wind = new WindGust();
		hwave = new HeatWave();
		ui = new FroggerUI(this);
		goalmanager = new GoalManager();

		movingObjectsLayer = new AbstractBodyLayer.IterativeUpdate<MovingEntity>();
		particleLayer = new AbstractBodyLayer.IterativeUpdate<MovingEntity>();

		gameState = GameState.INTRO;
		initializeLevel(1);
	}


	public void initializeLevel(int level) {

		/* dV is the velocity multiplier for all moving objects at the current game level */
		double dV = level*0.05 + 1;

		movingObjectsLayer.clear();

		/* River Traffic */
		riverLine1 = new MovingEntityFactory(new Vector2D(-(32*3),2*32), new Vector2D(0.06*dV,0));
		riverLine2 = new MovingEntityFactory(new Vector2D(FroggerGame.WORLD_WIDTH,3*32),  new Vector2D(-0.04*dV,0));
		riverLine3 = new MovingEntityFactory(new Vector2D(-(32*3),4*32), new Vector2D(0.09*dV,0));
		riverLine4 = new MovingEntityFactory(new Vector2D(-(32*4),5*32), new Vector2D(0.045*dV,0));
		riverLine5 = new MovingEntityFactory(new Vector2D(FroggerGame.WORLD_WIDTH,6*32), new Vector2D(-0.045*dV,0));

		/* Road Traffic */
		roadLine1 = new MovingEntityFactory(new Vector2D(FroggerGame.WORLD_WIDTH, 8*32), new Vector2D(-0.1*dV, 0));
		roadLine2 = new MovingEntityFactory(new Vector2D(-(32*4), 9*32), new Vector2D(0.08*dV, 0));
		roadLine3 = new MovingEntityFactory(new Vector2D(FroggerGame.WORLD_WIDTH, 10*32), new Vector2D(-0.12*dV, 0));
		roadLine4 = new MovingEntityFactory(new Vector2D(-(32*4), 11*32), new Vector2D(0.075*dV, 0));
		roadLine5 = new MovingEntityFactory(new Vector2D(FroggerGame.WORLD_WIDTH, 12*32), new Vector2D(-0.05*dV, 0));

		goalmanager.init(level);
		for (Goal g : goalmanager.get()) {
			movingObjectsLayer.add(g);
		}

		/* Build some traffic before game starts buy running MovingEntityFactories for fews cycles */
		for (int i=0; i<500; i++)
			cycleTraffic(10);
	}


	/**
	 * Populate movingObjectLayer with a cycle of cars/trucks, moving tree logs, etc
	 *
	 * @param deltaMs
	 */
	public void cycleTraffic(long deltaMs) {
		MovingEntity m;
		/* Road traffic updates */
		roadLine1.update(deltaMs);
		if ((m = roadLine1.buildVehicle()) != null) movingObjectsLayer.add(m);

		roadLine2.update(deltaMs);
		if ((m = roadLine2.buildVehicle()) != null) movingObjectsLayer.add(m);

		roadLine3.update(deltaMs);
		if ((m = roadLine3.buildVehicle()) != null) movingObjectsLayer.add(m);

		roadLine4.update(deltaMs);
		if ((m = roadLine4.buildVehicle()) != null) movingObjectsLayer.add(m);

		roadLine5.update(deltaMs);
		if ((m = roadLine5.buildVehicle()) != null) movingObjectsLayer.add(m);

		/* River traffic updates */
		riverLine1.update(deltaMs);
		if ((m = riverLine1.buildShortLogWithTurtles(40)) != null) movingObjectsLayer.add(m);

		riverLine2.update(deltaMs);
		if ((m = riverLine2.buildLongLogWithCrocodile(30)) != null) movingObjectsLayer.add(m);

		riverLine3.update(deltaMs);
		if ((m = riverLine3.buildShortLogWithTurtles(50)) != null) movingObjectsLayer.add(m);

		riverLine4.update(deltaMs);
		if ((m = riverLine4.buildLongLogWithCrocodile(20)) != null) movingObjectsLayer.add(m);

		riverLine5.update(deltaMs);
		if ((m = riverLine5.buildShortLogWithTurtles(10)) != null) movingObjectsLayer.add(m);

		// Do Wind
		if ((m = wind.genParticles(GameLevel)) != null) particleLayer.add(m);

		// HeatWave
		for(Frogger frog: frogs) {
			if ((m = hwave.genParticles(frog.getCenterPosition())) != null) particleLayer.add(m);
		}
		movingObjectsLayer.update(deltaMs);
		particleLayer.update(deltaMs);
	}

	public void keyboardHandler() {
		keyboard.poll();

		if(gameState == GameState.PLAY) {
			boolean keyReleased = false;
			boolean downPressed = keyboard.isPressed(KeyEvent.VK_DOWN);
			boolean upPressed = keyboard.isPressed(KeyEvent.VK_UP);
			boolean leftPressed = keyboard.isPressed(KeyEvent.VK_LEFT);
			boolean rightPressed = keyboard.isPressed(KeyEvent.VK_RIGHT);

			// Enable/Disable cheating

			if (keyboard.isPressed(KeyEvent.VK_C))
				mainFrog.cheating = true;
			if (keyboard.isPressed(KeyEvent.VK_V))
				mainFrog.cheating = false;
			if (keyboard.isPressed(KeyEvent.VK_0)) {
				GameLevel = 10;
				initializeLevel(GameLevel);
			}


			/*
			 * This logic checks for key strokes.
			 * It registers a key press, and ignores all other key strokes
			 * until the first key has been released
			 */
			if (downPressed || upPressed || leftPressed || rightPressed)
				keyPressed = true;
			else if (keyPressed)
				keyReleased = true;

			if (listenInput) {
				if (downPressed) mainFrog.moveDown();
				if (upPressed) mainFrog.moveUp();
				if (leftPressed) mainFrog.moveLeft();
				if (rightPressed) mainFrog.moveRight();

				if (keyPressed)
					listenInput = false;
			}

			if (keyReleased) {
				listenInput = true;
				keyPressed = false;
			}

			if (keyboard.isPressed(KeyEvent.VK_ESCAPE))
				gameState = GameState.INTRO;
		} else if(gameState == GameState.OVER || gameState == GameState.INSTRUCTIONS || gameState == GameState.INTRO) {
			if (keyboard.isPressed(KeyEvent.VK_SPACE)) {
				if (gameState == GameState.INSTRUCTIONS || gameState == GameState.OVER) {
					gameState = GameState.INTRO;
					space_has_been_released = false;
				} else {
					GameLives = FROGGER_LIVES;
					GameScore = 0;
					GameLevel = STARTING_LEVEL;
					levelTimer = DEFAULT_LEVEL_TIME;
					// Setup start position for each frog, based on FROGGER_START:
					Vector2D thisFroggerStart = FROGGER_START;
					for (Frogger frog: frogs) {
						frog.setPosition(thisFroggerStart);
						thisFroggerStart = thisFroggerStart.translate(
								new Vector2D(32, 0)
						);
					}
					// New game state, music and level:
					gameState = GameState.PLAY;
					audiofx.playGameMusic();
					initializeLevel(GameLevel);
				}
			}
			if (keyboard.isPressed(KeyEvent.VK_H))
				gameState = GameState.INSTRUCTIONS;
		} else {
			if (keyboard.isPressed(KeyEvent.VK_SPACE)) {
				gameState = GameState.PLAY;
				audiofx.playGameMusic();
				initializeLevel(++GameLevel);
			}
		}
	}

	/**
	 * w00t
	 */
	public void update(long deltaMs) {
		keyboardHandler();

		if(gameState == GameState.PLAY) {
			wind.update(deltaMs);
			hwave.update(deltaMs);
			for (Frogger frog: frogs) {
				frog.update(deltaMs);
			}
			audiofx.update(deltaMs);
			ui.update(deltaMs);

			cycleTraffic(deltaMs);
			frogCol.testCollision(movingObjectsLayer);

			// Wind gusts work only when Frogger is on the river
			for (Frogger frog: frogs) {
				if (frogCol.isInRiver())
					wind.start(GameLevel);
				wind.perform(frog, GameLevel, deltaMs);
			}

			// Do the heat wave only when Frogger is on hot pavement
			for (Frogger frog: frogs) {
				if (frogCol.isOnRoad())
					hwave.start(frog, GameLevel);
				hwave.perform(frog, deltaMs, GameLevel);
			}

			for (Frogger frog: frogs) {
				if (!frog.isAlive)
					particleLayer.clear();
			}

			goalmanager.update(deltaMs);

			if (goalmanager.getUnreached().size() == 0) {
				gameState = GameState.FINISH;
				audiofx.playCompleteLevel();
				particleLayer.clear();
			}

			if (GameLives < 1) {
				gameState = GameState.OVER;
			}
		} else if(gameState == GameState.OVER || gameState == GameState.INSTRUCTIONS || gameState == GameState.INTRO) {
			goalmanager.update(deltaMs);
			cycleTraffic(deltaMs);
		}
	}

	/**
	 * Rendering game objects
	 */
	public void render(RenderingContext rc) {
		backgroundLayer.render(rc);
		movingObjectsLayer.render(rc);
		if(gameState == GameState.FINISH || gameState == GameState.PLAY) {
			boolean anyFrogAlive = false;

			for (Frogger frog: frogs)
			{
				if (frog.isAlive) {
					anyFrogAlive = true;
					//frog.collisionObjects.get(0).render(rc);
					frog.render(rc);
				} else {
					frog.render(rc);
					movingObjectsLayer.render(rc);
				}
			}
			if (anyFrogAlive) {
				movingObjectsLayer.render(rc);
			}
			particleLayer.render(rc);
		}
		ui.render(rc);
	}

	public static void main (String[] args) throws RemoteException {
		FroggerGame f = new FroggerGame(null, null, null);
		f.run();
	}
}