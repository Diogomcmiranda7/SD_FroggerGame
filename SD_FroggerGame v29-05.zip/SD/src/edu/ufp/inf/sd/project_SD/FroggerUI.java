package edu.ufp.inf.sd.project_SD;

import java.awt.Color;
import java.awt.Font;
import java.awt.geom.AffineTransform;
import java.util.List;

import jig.engine.FontResource;
import jig.engine.ImageResource;
import jig.engine.RenderingContext;
import jig.engine.ResourceFactory;
import jig.engine.ViewableLayer;

public class FroggerUI implements ViewableLayer {
	List<ImageResource> heart = ResourceFactory.getFactory().getFrames(
			FroggerGame.SPRITE_SHEET + "#heart");
	List<ImageResource> gameOver = ResourceFactory.getFactory().getFrames(
			FroggerGame.SPRITE_SHEET + "#gameover");
	List<ImageResource> levelFinish = ResourceFactory.getFactory().getFrames(
			FroggerGame.SPRITE_SHEET + "#level_finish");
	List<ImageResource> introTitle = ResourceFactory.getFactory().getFrames(
			FroggerGame.SPRITE_SHEET + "#splash");
	List<ImageResource> instructions = ResourceFactory.getFactory().getFrames(
			FroggerGame.SPRITE_SHEET + "#help");
	
	FontResource font = ResourceFactory.getFactory().getFontResource(
			new Font("Sans Serif", Font.BOLD, 14), Color.white, null );

	FontResource fontBlack = ResourceFactory.getFactory().getFontResource(
			new Font("Sans Serif", Font.BOLD, 14), Color.black, null );
	
	FroggerGame game;
	
	public FroggerUI(final FroggerGame g) {
		game = g;
	}
	
	
	public void render(RenderingContext rc) {
		
		font.render("Time: " + game.levelTimer, rc, 
				AffineTransform.getTranslateInstance(180, 7));
		
		font.render("Score: " + game.GameScore, rc, 
				AffineTransform.getTranslateInstance(310, 7));
		
		if (game.GameLives > 0) {
			int dx = 0;
			
			// if player has more than 10 lives, draw only 10 hearts
			int maxHearts = game.GameLives;
			if (maxHearts > 10)
				maxHearts = 10;
			else 
				maxHearts = game.GameLives;
			
			for (int i = 0; i < maxHearts; i++ ) {
				heart.get(0).render(rc, 
						AffineTransform.getTranslateInstance(dx+8, 8));
				dx = 16 * (i + 1);
			}
		}

		font.render("L" + game.GameLevel, rc, 
				AffineTransform.getTranslateInstance(270, 7));
		
		if (game.gameState == FroggerGame.GameState.INTRO) {
			// Alterar Sprite para mostrar as outras opções
		   introTitle.get(0).render(rc, AffineTransform.getTranslateInstance((FroggerGame.WORLD_WIDTH - introTitle.get(0).getWidth())/2, 150));
		   return;
		}
		
		if (game.gameState == FroggerGame.GameState.INSTRUCTIONS) {
			   instructions.get(0).render(rc, 
						AffineTransform.getTranslateInstance(
								(FroggerGame.WORLD_WIDTH - instructions.get(0).getWidth())/2, 100));
			   return;			
		}
		
		if (game.gameState == FroggerGame.GameState.OVER) {
		   gameOver.get(0).render(rc, 
					AffineTransform.getTranslateInstance(
							(FroggerGame.WORLD_WIDTH - gameOver.get(0).getWidth())/2, 150));
		   return;
		}
		
		if (game.gameState == FroggerGame.GameState.FINISH) {
			 levelFinish.get(0).render(rc, 
						AffineTransform.getTranslateInstance(
								(FroggerGame.WORLD_WIDTH - levelFinish.get(0).getWidth())/2, 150));
		}
	}

	public void update(long deltaMs) {
	}

	public boolean isActive() {
		return true;
	}

	public void setActivation(boolean a) {
		// can't turn this layer off!
	}
	
}