package edu.ufp.inf.sd.project_SD.client;

import edu.ufp.inf.sd.project_SD.server.FroggerGameImpl;
import edu.ufp.inf.sd.project_SD.server.GameServer;


import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class FroggerImpl implements FroggerRI, Serializable {

    @Override
    public String getQueueGame() {
        return queue_game;
    }

    public String queue_game;

    private String name;

    private FroggerGameImpl froggerGame;

    private List<Thread> threads = new ArrayList<Thread>();

    public FroggerImpl(String name, FroggerGameImpl fg) throws IOException {
        this.name = name;
        this.froggerGame = fg;
        this.queue_game = name + "_ongame_" + fg.getName() + "_queue";
        GameServer.rabbitmqChannel.queueDeclare(this.queue_game,  false, false, false, null);
        GameServer.rabbitmqChannel.queueBind(this.queue_game, fg.getExchangeGame(), "");
    }


    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public FroggerGameImpl getFroggerGame() {
        return froggerGame;
    }



    @Override
    public FroggerImpl getFrogger() throws RemoteException {
        return this;
    }

    @Override
    public String toString() {
        return "FroggerImpl{" +
                ", name='" + name + '\'' +
                ", froggerGameName='" + froggerGame + '\'' +
                '}';
    }
}
