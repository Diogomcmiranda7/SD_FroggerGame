package edu.ufp.inf.sd.project_SD.client;


import java.rmi.Remote;
import java.rmi.RemoteException;


public interface FroggerRI extends Remote {


    String getQueueGame();

    String getName();

    FroggerImpl getFrogger() throws RemoteException;

}
