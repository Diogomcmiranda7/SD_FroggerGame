package edu.ufp.inf.sd.project_SD.client;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.DeliverCallback;
import com.rabbitmq.client.Delivery;
import edu.ufp.inf.sd.project_SD.FroggerGame;
import edu.ufp.inf.sd.project_SD.server.FroggerGameRI;
import edu.ufp.inf.sd.project_SD.server.AuthenticationRI;
import edu.ufp.inf.sd.project_SD.server.SessionRI;

import edu.ufp.inf.sd.project_SD.util.RabbitUtils;
import edu.ufp.inf.sd.project_SD.util.rmisetup.SetupContextRMI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.registry.Registry;

import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GameClient {

    public static String GAME_READY_MESSAGE = "game_is_ready";

    /**
     * Context for connecting a RMI client MAIL_TO_ADDR a RMI Servant
     */
    private SetupContextRMI contextRMI;
    /**
     * Remote interface that will hold the Servant proxy
     */
    private AuthenticationRI authenticationRI;

    private SessionRI sessionRI;

    private Connection rabbitmqConnection;

    private Channel rabbitmqChannel;

    private class FroggerDeliverCallback implements DeliverCallback {
        private FroggerGameRI froggerGame;

        public FroggerDeliverCallback(FroggerGameRI froggerGame) {
            this.froggerGame = froggerGame;
        }

        @Override
        public void handle(String consumerTag, Delivery delivery) throws IOException {
            String message = new String(delivery.getBody(), "UTF-8");
            if (message.equals(GAME_READY_MESSAGE)) {
                showGameWindow(this.froggerGame);
            }
            System.out.println(" [x] Received '" + message + "'");
        }
    }

    public static void main(String[] args) {
        if (args != null && args.length < 2) {
            System.err.println("usage: java [options] edu.ufp.inf.sd.project_SD.server.GameServer <rmi_registry_ip> <rmi_registry_port> <service_name>");
            System.exit(-1);
        } else {
            //1. ============ Setup client RMI context ============
            GameClient gc = new GameClient(args);
            //2. ============ Lookup service ============
            gc.lookupService();
            //3. ============ Play with service ============
            gc.playService();
        }
    }

    public GameClient(String args[]) {
        try {
            //List ans set args
            SetupContextRMI.printArgs(this.getClass().getName(), args);
            String registryIP = args[0];
            String registryPort = args[1];
            String serviceName = args[2];

            //open Rabbitmq connection
            rabbitmqConnection = RabbitUtils.newConnection2Server(registryIP, 5672, "guest", "guest");
            rabbitmqChannel = RabbitUtils.createChannel2Server(rabbitmqConnection);

            //Create a context for RMI setup
            contextRMI = new SetupContextRMI(this.getClass(), registryIP, registryPort, new String[]{serviceName});
        } catch (RemoteException e) {
            Logger.getLogger(GameClient.class.getName()).log(Level.SEVERE, null, e);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TimeoutException e) {
            e.printStackTrace();
        }
    }

    public Remote lookupService() {
        try {
            //Get proxy MAIL_TO_ADDR rmiregistry
            Registry registry = contextRMI.getRegistry();
            //Lookup service on rmiregistry and wait for calls
            if (registry != null) {
                //Get service url (including servicename)
                String serviceUrl = contextRMI.getServicesUrl(0);
                Logger.getLogger(this.getClass().getName()).log(Level.INFO, "going MAIL_TO_ADDR lookup service @ {0}", serviceUrl);

                //============ Get proxy MAIL_TO_ADDR HelloWorld service ============
                authenticationRI = (AuthenticationRI) registry.lookup(serviceUrl);
            } else {
                Logger.getLogger(this.getClass().getName()).log(Level.INFO, "registry not bound (check IPs). :(");
                //registry = LocateRegistry.createRegistry(1099);
            }
        } catch (RemoteException | NotBoundException ex) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return authenticationRI;
    }

    public void playService() {
        try {
            //============ Call MENU remote service ==================
            System.out.println("\n" + "1: REGISTO \n" + "2: LOGIN \n");
            String option = null;
            while (option == null || (!option.equals("1") && !option.equals("2"))) {
                option = this.readInput("option");
            }
            String name = this.readInput("name");
            String pass = this.readInput("pass");

            if (option.equals("1")) {
                FroggerGameRI subject = null;
                boolean check = this.authenticationRI.register(name, pass);
                if (check) {
                    sessionRI = this.authenticationRI.login(name, pass);
                }

            } else if (option.equals("2")) {
                this.sessionRI = null;
                while (this.sessionRI == null) {
                    sessionRI = this.authenticationRI.login(name, pass);
                }
            }

            String frogNameOfFrogger;
            Integer menuOption = -2;
            while (!menuOption.equals(-1)) {
                System.out.println("Choose:");
                System.out.println("1: CREATE FROGGER GAME");
                System.out.println("2: DELETE FROGGER GAME");
                System.out.println("3: LIST FROGGER GAME");
                System.out.println("4: ASSOCIATE FROGGER AT FROGGER GAME");
                System.out.println("5: LIST FROGGERS OF FROGGER GAME");
                System.out.println("6: LOGOUT");
                try {
                    menuOption = Integer.valueOf(this.readInput("Menu Option"));
                } catch (java.lang.NumberFormatException nfe) {
                    System.out.println("Invalid input. Please insert a number from 1 to 6.");
                    continue;
                }
                System.out.println(menuOption);

                switch (menuOption) {
                    case 1:
                        String frogNameCreate = this.readInput("Frog Name To Create");
                        FroggerRI theFrogger = this.sessionRI.createFroggerGame(frogNameCreate);
                        if (theFrogger == null)
                            System.out.println("Frogname '" + frogNameCreate + "' already been used, Choose wisely!\n");
                        // Setup a callback to receive messages from the queue:
                        consumeFroggerMessages(
                                this.sessionRI.getFroggerGame(frogNameCreate),
                                theFrogger);
                        menuOption = 0;
                        break;

                    case 2:
                        frogNameOfFrogger = this.readInput("Frog Name To Delete");
                        boolean checkDelete = this.sessionRI.deleteFroggerGame(frogNameOfFrogger);
                        if (checkDelete == false)
                            System.out.println("\n Frogger Game '" + frogNameOfFrogger + "' couldn't get deleted!!");
                        else System.out.println("\n Frogger Game'" + frogNameOfFrogger + "' has been deleted!!");
                        menuOption = 0;
                        break;

                    case 3:
                        for (String frog : this.sessionRI.listFroggerGames()) {
                            System.out.println(frog);
                        }
                        menuOption = 0;
                        break;

                    case 4:
                        String frogNameAttachFrogger = this.readInput("Frogger game name to attach");

                        FroggerGameRI theFroggerGame = this.sessionRI.attachFrogger(frogNameAttachFrogger);
                        if (theFroggerGame == null)
                            System.out.println("Unable to attach to game '" + frogNameAttachFrogger + "'!!");
                        else System.out.println("Now attached to game '" + frogNameAttachFrogger + "'!!");

                        menuOption = 0;
                        if (theFroggerGame != null) {
                            FroggerRI myFrogger = this.sessionRI.getFrogger(
                                    // FroggerGame name - Just read from the terminal.
                                    frogNameAttachFrogger,
                                    // Current user name - The Frogger has the same name as the user who created it
                                    name);
                            consumeFroggerMessages(theFroggerGame, myFrogger);
                            rabbitmqChannel.basicPublish(
                                    theFroggerGame.getExchangeGame(),
                                    "",
                                    null,
                                    GAME_READY_MESSAGE.getBytes("UTF-8"));
                        }
                        break;
                    case 5:
                        frogNameOfFrogger = this.readInput("Frog Name To See Froggers");
                        System.out.println("\n Froggers from " + frogNameOfFrogger + ":\n");
                        for (String f : this.sessionRI.listFroggers(frogNameOfFrogger)) {
                            System.out.println(f);
                        }
                        menuOption = 0;
                        break;

                    case 6:
                        this.sessionRI.logout();
                        menuOption = -1;
                        break;

                    default:
                        System.out.println("Invalid option: " + menuOption);
                        break;
                }
            }

            Logger.getLogger(this.getClass().getName()).log(Level.INFO, "");
        } catch (RemoteException ex) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void consumeFroggerMessages(FroggerGameRI froggerGame, FroggerRI checkCreate) throws IOException {
        String myQueueNameInGame = checkCreate.getQueueGame();
        DeliverCallback deliverCallback = new FroggerDeliverCallback(froggerGame);
        rabbitmqChannel.basicConsume(
                myQueueNameInGame,
                true,
                deliverCallback,
                consumerTag -> {
                });
    }

    private void showGameWindow(FroggerGameRI froggerGame) throws RemoteException {
        FroggerGame f = new FroggerGame(
                this.sessionRI,
                froggerGame,
                this.sessionRI.getUserName());
        f.run();
    }

    private boolean register(String name, String pass) {
        boolean regist = false;
        try {
            regist = authenticationRI.register(name, pass);
        } catch (RemoteException e) {
            Logger.getLogger(this.getClass().getName()).log(Level.INFO, "Exception in register");
        }
        return regist;
    }

    public String readInput(String dados) {
        System.out.println("\n Insert " + dados);
        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
        String name = null;
        try {
            name = bufferRead.readLine();
            if (name == null || name.isEmpty()) {
                readInput("option");
            }
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return name;
    }
}
