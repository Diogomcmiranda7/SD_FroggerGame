package edu.ufp.inf.sd.project_SD.producer;

import com.rabbitmq.client.*;
import edu.ufp.inf.sd.project_SD.util.RabbitUtils;

import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * RabbitMQ speaks multiple protocols. This tutorial uses AMQP 0-9-1, which is
 * an open, general-purpose protocol for messaging. There are a number of
 * clients for RabbitMQ in many different languages. We'll use the Java client
 * provided by RabbitMQ.
 * <p>
 * Download client library (amqp-client-4.0.2.jar) and its dependencies (SLF4J
 * API and SLF4J Simple) and copy them into lib directory.
 * <p>
 * Jargon terms:
 * RabbitMQ is a message broker, i.e., a server that accepts and forwards messages.
 * Producer is a program that sends messages (Producing means sending).
 * Queue is a post box which lives inside a RabbitMQ broker (large message buffer).
 * Consumer is a program that waits to receive messages (Consuming means receiving).
 * The server, client and broker do not have to reside on the same host
 *
 * @author rui
 */
public class Producer {

    /*+ name of the queue */
    public final static String QUEUE_NAME="jssp_ga";

    public static void main(String[] argv) {

        RabbitUtils.printArgs(argv);

        if (argv.length < 4) {
            System.err.println("Usage: Consumer [HOST] [PORT] [QUEUE] [RoutingKey] [Message]");
            System.exit(1);
        }

        //Read args passed via shell command
        String host=argv[0];
        int port=Integer.parseInt(argv[1]);
        String queueName=argv[2];

        ConnectionFactory factory=new ConnectionFactory();
        factory.setHost("localhost");


        try (Connection connection=RabbitUtils.newConnection2Server(host, port, "guest", "guest");
             Channel channel=RabbitUtils.createChannel2Server(connection)) {


           channel.queueDeclare(QUEUE_NAME, false, false, false, null);

            message(channel, "stop");

            String routingKey=RabbitUtils.getRouting(argv, 3);

            String message=RabbitUtils.getMessage(argv, 4);

            AMQP.BasicProperties props=null;

            channel.basicPublish(QUEUE_NAME, routingKey, props, message.getBytes("UTF-8"));
            System.out.println(" [x] Sent " + routingKey + " " + message + " ");

        } catch (IOException | TimeoutException e) {
            Logger.getLogger(Producer.class.getName()).log(Level.INFO, e.toString());
        }
    }

    private static void message(Channel channel, String valueOf) {
    }
}
