package edu.ufp.inf.sd.project_SD.server;

import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;


public class AuthenticationImpl extends UnicastRemoteObject implements AuthenticationRI {

    public DataBase dataBase;

    private HashMap<String, SessionRI> sessions = new HashMap<>();

    public AuthenticationImpl() throws RemoteException {
        super();
        if (System.getSecurityManager() == null)
            System.setSecurityManager ( new RMISecurityManager() );
        dataBase = new DataBase();
    }

    /**
     * faz o registo daquele utilizador:
     * vai à base de dados verificar se o username já existe e adiciona
     *
     * @param username - a adicionar
     * @param pass     - passe do user
     * @return true se não houver nenhum username igual, false se já houver igual
     * @throws RemoteException
     */
    @Override
    public boolean register(String username, String pass) throws RemoteException {
        return dataBase.registerUser(username, pass) != null;
    }

    /**
     * fazer com que o user faça login:
     * procura se já existe na base de dados, o username com aquela pass associada
     *
     * @param username - username do user a tentar fazer login
     * @param pass     - pass inserida para o login
     * @return uma sessao para aquele utilizador
     * @throws RemoteException
     */
    @Override
    public SessionRI login(String username, String pass) throws RemoteException {
        User user = dataBase.verifyUser(username, pass);
        if(user == null) {
            return null;
        }
        SessionRI session = new SessionImpl(dataBase, this, user.getName());
        sessions.put(username, session);
        return session;
    }


    /**
     * faz logout : remove a sessao na lista
     *
     * @param username - o user que quer fazer logout
     */
    @Override
    public void logout(String username) {
        sessions.remove(username);
    }

}
