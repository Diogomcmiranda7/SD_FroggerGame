package edu.ufp.inf.sd.project_SD.server;

import edu.ufp.inf.sd.project_SD.client.FroggerImpl;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

public class DataBase implements Serializable {


    List<FroggerGameImpl> allFroggerGames = new ArrayList<>();
    // hashmap of froggerGame of users (the string is the name of user)
    HashMap<String, List<FroggerGameImpl>> froggerGames = new HashMap<String, List<FroggerGameImpl>>();
    //hashmap of froggerGame of froggers ( the string is the name of frogger game)
    HashMap<String, List<FroggerImpl>> frogFroggers = new HashMap<String, List<FroggerImpl>>();
    private Vector<User> users = new Vector<>();


    public DataBase() {
        super();
    }

    /**
     * regista o utilizador/user na base de dados com o seu username único e a sua pass
     *
     * @param username único
     * @param pass     do user
     * @return o user/utilizador criado
     */
    public User registerUser(String username, String pass) {
        if(userExists(username)) {
            System.out.println("Oh no, User " + username + " couldn't been created, username already taken!");
            return null;
        }

        User user = new User(username, pass);
        users.add(user); //add user in hash map of users
        froggerGames.put(user.getName(), new ArrayList<FroggerGameImpl>()); //add user with empty frogger games list
        System.out.println("User " + username + " has been created!");
        printUsers();
        return user;
    }

    /**
     * verifica se o username do utilizador já se encontra na base de dados
     *
     * @param name username a ser procurado, a verificar se existe
     * @return true se já existe, false se não existe
     */
    public boolean userExists(String name) {
        for (User u : this.users) {
            if (u.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * vai a todos os users e guarda numa string
     *
     * @return a string com todos os utilizadores, username e pass
     */
    public String printUsers() {
        String s = "";
        for (User user : this.users) {
            s += "username:" + user.name + " pass: " + user.pass;
            s += "\n";
        }
        return s;
    }

    /**
     * verifica se o username e a pass correspondem à guardada na base de dados
     *
     * @param username do user a fazer login
     * @param pass     do user a fazer login
     * @return o user se encontrar, se não encontrar/não existir retorna null
     */
    public User verifyUser(String username, String pass) {
        printUsers();
        for (User u : users) {
            if (u.getName().equals(username) && u.getPass().equals(pass)) {
                return u;
            }
        }
        return null;
    }

    /**
     * Dado o username, retorna os froggerGames que estão associadas ao user
     *
     * @param username do user
     * @return lista de froggergames que correspondem ao user
     */
    public List<FroggerGameImpl> getFroggerGamesOfUser(String username) {
        if (this.froggerGames.get(username) == null) {
            System.out.println("There aren't any frogs with that username!!!");
        }
        return this.froggerGames.get(username);
    }

    /**
     * adiciona o froggerGame na base de dados, com o owner do frog
     *
     * @param froggerGame frog a guardar
     */
    public void addFroggerGame(FroggerGameImpl froggerGame) {
        List<FroggerGameImpl> myFrogs = this.getFroggerGamesOfUser(froggerGame.getOwner());//ir buscar a lista de froggerGame do user
        if (myFrogs == null) {//adicionar o froggergame na lista
            myFrogs = new ArrayList<FroggerGameImpl>();
        }
        myFrogs.add(froggerGame);
        this.froggerGames.put(froggerGame.getOwner(), myFrogs); // guardar na database
        this.frogFroggers.put(froggerGame.getName(), new ArrayList<FroggerImpl>()); // guardar na database
        this.allFroggerGames.add(froggerGame); //lista com todos os jogos
    }

    /**
     * elimina o froggerGame da base de dados
     *
     * @param fg frog a eliminar
     */
    public void deleteFroggerGame(FroggerGameImpl fg) {
        List<FroggerGameImpl> frogs = this.getFroggerGamesOfUser(fg.getOwner());
        frogs.remove(fg);
    }

    /**
     * procura o froggergame com x nome e y owner e devolve-a
     *
     * @param froggerGameName - nome do froggergame que se procura
     * @return o froggergame procurada se encontrar, null se não houver nenhum frog com aquele nome pertencente aquele user
     */
    public FroggerGameImpl getFroggerGamesByName(String froggerGameName) {
       for ( FroggerGameImpl fg : this.allFroggerGames ) {
            if (fg.getName().equals(froggerGameName)) {
                return fg;
            }
        }
        return null;
    }

    /**
     * procura todos os froggers de x froggergame
     *
     * @param frogName - a que pertencem os froggers a procurar
     * @return todos os froggers de x froggergame
     */
    public List<FroggerImpl> getFroggersOfFroggerGame(String frogName) {
        return this.frogFroggers.get(frogName);
    }


    public List<FroggerGameImpl> getAllFroggerGames() {
        return this.allFroggerGames;
    }

    //Adiciona um jogador ao jogo
    public void addGameToFrogger(FroggerImpl frogger, FroggerGameImpl fg) throws RemoteException {
            frogFroggers.get(fg.getName()).add(frogger);


    }

    public FroggerImpl getFroggerByName(String gameName, String userName)
    {
        List<FroggerImpl> froggersOfTheGame = this.getFroggersOfFroggerGame(gameName);
        for (FroggerImpl frogger : froggersOfTheGame) {
            if(frogger.getName().equals(userName)){
                return frogger;
            }
        }
        return null;
    }
}
