package edu.ufp.inf.sd.project_SD.server;

import com.rabbitmq.client.BuiltinExchangeType;
import edu.ufp.inf.sd.project_SD.client.FroggerRI;

import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;



public class FroggerGameImpl implements FroggerGameRI, Serializable {

    @Override
    public String getExchangeGame() {
        return exchange_game;
    }

    private String exchange_game; //nome que envia as msg (exchange por jogo)

    private Long id;

    private String name;

    private DataBase database;

    private String owner;

    @Override
    public List<FroggerRI> getFroggers() {
        return froggers;
    }

    private List<FroggerRI> froggers;

    public FroggerGameImpl(String owner, String name) throws IOException {
        this.owner = owner;
        this.name = name;
        this.exchange_game = name + "_exchange";
        GameServer.rabbitmqChannel.exchangeDeclare(this.exchange_game, BuiltinExchangeType.FANOUT);
        this.froggers = new ArrayList<>();
        //export();
    }


    /**
     * adiciona frogger passado em parametro ao array list de froggers do froggergame
     *
     * @param f - frogger a ser adicionado
     * @throws RemoteException
     */
    public void attach(FroggerRI f) throws RemoteException {
        this.froggers.add(f);
    }


    /**
     * a retirar localmente para enviar ao rmi
     *
     * @throws RemoteException
     */
    public void export() throws RemoteException {
        UnicastRemoteObject.exportObject(this, 0);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwner() {
        return owner;
    }


    @Override
    public String toString() {
        return "JobGroupImpl{" +
                "name='" + name + '\'' +
                ", owner='" + owner + '\'' +
                '}';
    }

}
