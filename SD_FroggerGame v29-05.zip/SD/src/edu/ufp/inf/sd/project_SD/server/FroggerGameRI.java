package edu.ufp.inf.sd.project_SD.server;

import edu.ufp.inf.sd.project_SD.client.FroggerRI;

import java.rmi.Remote;
import java.util.List;


public interface FroggerGameRI extends Remote {

    public String getExchangeGame();

    List<FroggerRI> getFroggers();

    public  String getName();


   /* void setReadyStatus() throws RemoteException;
    void moveUp() throws RemoteException;
    void moveDown() throws RemoteException;
    void moveLeft() throws RemoteException;
    void moveRight() throws RemoteException;*/


}
