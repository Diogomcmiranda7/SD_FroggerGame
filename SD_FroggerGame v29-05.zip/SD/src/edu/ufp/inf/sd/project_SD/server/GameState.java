package edu.ufp.inf.sd.project_SD.server;

import edu.ufp.inf.sd.project_SD.client.FroggerImpl;

public class GameState {

    public String tSearchCode;

    public FroggerImpl frogger;

    public Thread thread;

    public String pass ="";

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public GameState(String tSearchCode, FroggerImpl frogger, Thread thread, String pass) {
        this.tSearchCode = tSearchCode;
        this.frogger = frogger;
        this.thread = thread;
        this.pass = pass;
    }

    @Override
    public String toString() {
        return "State{" +
                "tSearchCode='" + tSearchCode + '\'' +
                ", frogger =" + frogger +
                '}';
    }
}
