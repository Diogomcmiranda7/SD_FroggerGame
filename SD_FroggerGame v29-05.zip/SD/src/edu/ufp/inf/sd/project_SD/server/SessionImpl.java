package edu.ufp.inf.sd.project_SD.server;

import edu.ufp.inf.sd.project_SD.client.FroggerImpl;
import edu.ufp.inf.sd.project_SD.client.FroggerRI;

import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class SessionImpl implements SessionRI {

    DataBase dataBase;

    String username;

    private AuthenticationImpl game;

    public SessionImpl(DataBase dataBase, AuthenticationImpl gameImpl, String user) throws RemoteException {
        this.game = gameImpl;
        this.dataBase = dataBase;
        this.username = user;
        String users = dataBase.printUsers();
        System.out.println(users);
        UnicastRemoteObject.exportObject(this, 0);
    }

    @Override
    public String getUserName() {
        return this.username;
    }

    /**
     * cria froggerGame se nome do frog for válido:
     * vai procurar se o nome do frog já existe na base de dados,
     * se não existir, insere no array de sessões da base de dados daquele utilizador
     *
     * @param name - nome do frog a criar - unico
     * @return false se for null o nome ou se já houver um frog com aquele nome, true se conseguir criar na base de dados
     * @throws RemoteException
     */
    @Override
    public FroggerRI createFroggerGame(String name) throws IOException {
        if (username == null) {
            System.out.println("username is null \n");
            return null;
        }
        FroggerGameImpl froggerGame = new FroggerGameImpl(username, name);
        if (this.dataBase.getFroggerGamesOfUser(username) != null) {
            for (FroggerGameImpl fg : this.dataBase.getFroggerGamesOfUser(username)) {
                if (fg.getName().equals(name)) { // frog name already been created then return false
                    return null;
                }
            }
        }
        this.dataBase.addFroggerGame(froggerGame);
        FroggerRI createdFrogger = createFroggerOnGame(username, froggerGame);
        return createdFrogger;
    }

    /**
     * lista froggergame varios utilizador
     *
     * @return lista de strings com info dos frogs
     * @throws RemoteException
     */
    @Override
    public List<String> listFroggerGames() throws RemoteException {
        List<String> frogs = new ArrayList<>();
        for (FroggerGameImpl fg : this.dataBase.getAllFroggerGames()) {
          frogs.add(fg.getName());
        }
        return frogs;
    }

    /**
     * elimina frog da base de dados
     *
     * @param name - nome do frog a eliminar
     * @return true se eliminar da base de dados, false se não houver nenhum frog com aquele nome
     * @throws RemoteException
     */
    @Override
    public boolean deleteFroggerGame(String name) throws RemoteException {
        if (this.dataBase.getFroggerGamesOfUser(username) != null) {
            for (FroggerGameImpl fg : this.dataBase.getFroggerGamesOfUser(username)) {
                if (fg.getName().equals(name)) {
                    this.dataBase.deleteFroggerGame(fg);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * associa frogger a determinado froggergame:
     * vai à base de dados procurar o frog,
     * cria frogger com aquele nome,
     * adiciona o frogger no array de froggers daquele frog
     *
     * @param froggerGameName  - nome do frog a ser associada ao frogger
     * @return false se não conseguir adicionar, true se conseguir adicionar o frogger ao frog
     * @throws RemoteException
     */
    @Override
    public FroggerGameRI attachFrogger(String froggerGameName) throws RemoteException {
        // Ver se o username atual já pertence àquele jogo:
        FroggerGameImpl fg = this.dataBase.getFroggerGamesByName(froggerGameName);
        if (fg != null) {
            createFroggerOnGame(username, fg);
        }
        return fg;
    }

    private FroggerImpl createFroggerOnGame(String froggerName, FroggerGameImpl fg) throws RemoteException{
        // Se não, cria o Frogger, para associar o user ao jogo:
        FroggerImpl frogger = null;
        try {
            frogger = new FroggerImpl(froggerName, fg);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Associa o frogger àquele jogo:
        //fg.attach(frogger);//put array list
        this.dataBase.addGameToFrogger(frogger, fg);
        fg.attach(frogger);

        return frogger;
    }




    /**
     * procura frog pelo nome e lista os seus froggers
     *
     * @param froggerGameName - nome do frog a procurar
     * @return - lista de strings com info dos froggers daquele frog
     * @throws RemoteException
     */
    @Override
    public List<String> listFroggers(String froggerGameName) throws RemoteException {
        System.out.println("\nlistFrogger():");
        List<String> froggers = new ArrayList<>();
        if (this.dataBase.getFroggersOfFroggerGame(froggerGameName) != null) {
            for (FroggerImpl frogger : this.dataBase.getFroggersOfFroggerGame(froggerGameName)) {
                System.out.println("listFroggers(): frogger=" + frogger.getName());
                froggers.add(frogger.getName());
            }
            return froggers;
        }
        return new ArrayList<>();
    }


    /**
     * termina sessao - logout
     * retira sessao com este username do user do array de sessoes
     *
     * @throws RemoteException
     */
    @Override
    public void logout() throws RemoteException {
        game.logout(this.username);
    }

    /**
     * Gets frogger object representing username in a given game. You have to
     * provide the game name because a user may be present in several games at once!
     * @param gameName    The game name in which to find the frogger object.
     * @param userName    The user name, which is also the name of the frogger.
     */
    @Override
    public FroggerRI getFrogger(String gameName, String userName) throws RemoteException{
        return dataBase.getFroggerByName(gameName, userName);
    }

    @Override
    public FroggerGameRI getFroggerGame(String name) throws RemoteException{
        return dataBase.getFroggerGamesByName(name);
    }
}
