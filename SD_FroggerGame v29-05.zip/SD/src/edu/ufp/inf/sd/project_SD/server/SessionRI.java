package edu.ufp.inf.sd.project_SD.server;

import edu.ufp.inf.sd.project_SD.client.FroggerRI;

import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface SessionRI extends Remote {
    /**
     * criar froggergame se nome do frog for válido:
     * vai procurar se o nome do frog já existe na base de dados,
     * se não existir, insere no array de sessões da base de dados daquele utilizador
     *
     * @param name - nome do frog a criar - unico
     * @return false se for null o nome ou se já houver um frog com aquele nome, true se conseguir criar na base de dados
     * @throws RemoteException
     */
    FroggerRI createFroggerGame(String name) throws IOException;

    /**
     * elimina frog da base de dados
     *
     * @param name - nome do frog a eliminar
     * @return true se eliminar da base de dados, false se não houver nenhum frog com aquele nome
     * @throws RemoteException
     */
    boolean deleteFroggerGame(String name) throws RemoteException;

    /**
     * lista froggergame daquele utilizador
     *
     * @return lista de strings com info dos frogs
     * @throws RemoteException
     */
    List<String> listFroggerGames() throws RemoteException;

    /**
     * procura frog pelo nome e lista os seus froggers
     *
     * @param froggerGameName - nome do frog a procurar
     * @return - lista de strings com info dos froggers daquele frog
     * @throws RemoteException
     */
    List<String> listFroggers(String froggerGameName) throws RemoteException;

    /**
     * associa frogger a determinado froggergame:
     * vai à base de dados procurar o frog,
     * cria frogger com aquele nome,
     * adiciona o frogger no array de froggers daquele frog
     *
     * @return false se não conseguir adicionar, true se conseguir adicionar o frog ao froggerGame
     * @throws RemoteException
     */
    FroggerGameRI attachFrogger(String froggerGameName) throws IOException;

    /**
     * termina sessao - logout
     * retira sessao com este username do user do array de sessoes do game
     *
     * @throws RemoteException
     */
    void logout() throws RemoteException;

    FroggerRI getFrogger(String gameName, String userName) throws RemoteException;

    FroggerGameRI getFroggerGame(String name) throws RemoteException;

    String getUserName() throws RemoteException;
}
